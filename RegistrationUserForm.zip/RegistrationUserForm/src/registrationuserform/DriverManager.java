/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrationuserform;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Anwar-PC
 */
class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306saima, String root, String root0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
